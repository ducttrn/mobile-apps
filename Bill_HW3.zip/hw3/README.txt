AUTHOR: Bill Tran

APP NAME: HOW IS YOUR DAY?

FUNCTIONALITY: The app asks users to describe their day, then detect the sentiment of the text (Positive/Negative) and recommends a suitable and customized meme.

UNIQUENESS: the app uses my own API to detect the sentiment of the text by making HTTP requests.